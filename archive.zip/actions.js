export const USERS = 'USERS';
export const QUESTION = 'QUESTION';
export const NAME = 'NAME';
export const ANSWER = 'ANSWER';
export const CONNECT = 'CONNECT';